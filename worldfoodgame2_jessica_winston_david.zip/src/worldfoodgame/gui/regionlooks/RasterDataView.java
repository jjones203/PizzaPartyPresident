package worldfoodgame.gui.regionlooks;

import java.awt.image.BufferedImage;

/**
 * Created by winston on 4/1/15.
 */
public interface RasterDataView
{
  BufferedImage getRasterImage();
}
