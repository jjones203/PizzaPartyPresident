package worldfoodgame.common;

/**
 * The AbstractCountryBorderData class should be extended by a class that
 * somehow represents a country's boarder.
 */
public abstract class AbstractCountryBorderData
{

}
