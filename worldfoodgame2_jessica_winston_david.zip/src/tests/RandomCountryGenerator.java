package tests;

import java.util.Random;

/**
 * Created by winston on 3/10/15.
 */
public class RandomCountryGenerator
{
  private Random random;

}
