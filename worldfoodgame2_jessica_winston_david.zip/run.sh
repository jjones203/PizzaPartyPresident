#!/bin/sh
java -classpath ./lib/rsyntaxtextarea.jar:./lib/commons-csv-1.1.jar:./out Game
