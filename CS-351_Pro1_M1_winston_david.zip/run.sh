#/bin/sh

java -classpath ./lib/rsyntaxtextarea.jar:./out Game
